package com.joyjit.foodspot.utility

class SessionManager(){
}