package com.joyjit.foodspot.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.core.app.ActivityCompat.finishAffinity
import com.joyjit.foodspot.R
import kotlinx.android.synthetic.main.activity_order_placed.*

class OrderPlacedActivity : AppCompatActivity() {
    lateinit var btnOk :Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_placed)

        btnOk = findViewById(R.id.butOk)

        butOk.setOnClickListener {
            startActivity(Intent(this, HomePage::class.java))
            finish()
        }
    }
}