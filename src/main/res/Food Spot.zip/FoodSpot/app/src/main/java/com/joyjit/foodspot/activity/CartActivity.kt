package com.joyjit.foodspot.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.joyjit.foodspot.R
import com.joyjit.foodspot.adapter.OrderRecyclerAdapter
import com.joyjit.foodspot.database.CartEntity
import com.joyjit.foodspot.database.FoodDatabase
import com.joyjit.foodspot.model.RestaurantMenu
import com.joyjit.foodspot.utility.ConnectionManager
import kotlinx.android.synthetic.main.activity_cart.*
import kotlinx.android.synthetic.main.activity_order_placed.*
import org.json.JSONArray
import org.json.JSONObject

class CartActivity : AppCompatActivity() {
    lateinit var recyclerOrder: RecyclerView
    lateinit var recyclerAdapter: OrderRecyclerAdapter
    lateinit var btnPlaceOrder: Button
    lateinit var txtOrderedFrom:TextView
    lateinit var sharedPreferences:SharedPreferences
    private var sum = 0
    var orderList = arrayListOf<RestaurantMenu>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
        recyclerOrder = findViewById(R.id.recyclerOrder)
        btnPlaceOrder = findViewById(R.id.butPlaceOrder)
        txtOrderedFrom = findViewById(R.id.txtOrderFrom)

        sharedPreferences = getSharedPreferences(getString(R.string.profile_data), MODE_PRIVATE)
       val userId =  sharedPreferences.getString("userId","userId")
        val resId = intent.getStringExtra("resId")
        val resName = intent.getStringExtra("resName")

        txtOrderedFrom.text = "Ordered From : ${resName}"

        supportActionBar?.title = "My Cart"
        val get = GetData(applicationContext).execute().get()
        for (i in get) {
            orderList.addAll( Gson().fromJson(i.foodItems, Array<RestaurantMenu>::class.java).asList())
            val layoutManager = LinearLayoutManager(this)
            recyclerAdapter = OrderRecyclerAdapter(this,orderList)
            recyclerOrder.adapter = recyclerAdapter
            recyclerOrder.layoutManager = layoutManager
        }

        for(i in 0 until  orderList.size){
            sum += orderList[i].price.toInt()
        }
        butPlaceOrder.text = "Placed Order (${sum})"


        val queue = Volley.newRequestQueue(this)
        val url = "http://13.235.250.119/v2/place_order/fetch_result/"

        val jsonArray = JSONArray()
        for(i in 0 until  orderList.size){
            val foodId = JSONObject()
            foodId.put("foodId", orderList[i].id)
            jsonArray.put(i,foodId)
        }

        val jsonParams = JSONObject()
        jsonParams.put("user_id",userId)
        jsonParams.put("res_Id",resId)
        jsonParams.put("total_cost",sum)
        jsonParams.put("food", jsonArray)


        btnPlaceOrder.setOnClickListener {
            if (ConnectionManager().checkConnectivity(this)) {
                val jsonObjectRequest =
                    object : JsonObjectRequest(
                        Method.POST, url, jsonParams,
                        Response.Listener {
                            val data = it.getJSONObject("data")
                            val success = data.getBoolean("success")
                            if (success) {
                                startActivity(Intent(this, OrderPlacedActivity::class.java))
                                ActivityCompat.finishAffinity(this)
                            }
                        }, Response.ErrorListener {
                            Toast.makeText(
                                this,
                                "error $it",
                                Toast.LENGTH_SHORT
                            ).show()
                        }) {
                        override fun getHeaders(): MutableMap<String, String>{
                            val headers = HashMap<String, String>()
                            headers["Content-type"] = "application/json"
                            headers["token"] = "9bf534118365f1"
                            return headers
                        }
                    }
                queue.add(jsonObjectRequest)
            } else {
                val dialog = AlertDialog.Builder(this,)
                dialog.setTitle("Error")
                dialog.setMessage("Internet Connection Not Found.")

                dialog.setPositiveButton("OpenSetting") { text, listener ->
                    val settingsIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    startActivity(settingsIntent)
                    this?.finish()
                }
                dialog.setNegativeButton("Exit") { text, listener ->
                    ActivityCompat.finishAffinity(this)
                }
                dialog.create()
                dialog.show()
            }
        }
    }

    class GetData(context: Context) : AsyncTask<Void, Void, List<CartEntity>>() {
        val db = Room.databaseBuilder(context, FoodDatabase::class.java, "foods_db").build()
        override fun doInBackground(vararg params: Void?): List<CartEntity> {
            return db.cartDao().getAllCart()
        }
    }
}