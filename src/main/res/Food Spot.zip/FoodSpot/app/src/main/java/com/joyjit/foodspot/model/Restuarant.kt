package com.joyjit.foodspot.model

data class Restuarant(
    val resId : String,
    val resName: String,
    val resRating: String,
    val resPrice: String,
    val resImage:String,
)