package com.joyjit.foodspot.model

data class RestaurantMenu(
    val id: Int,
    val name: String,
    val price: String,
    val Restaurant_id: String
)
